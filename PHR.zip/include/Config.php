<?php

/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "igrus");
define("DB_PASSWORD", "Dkdlrmfntm123");
define("DB_DATABASE", "igrus");
?>
